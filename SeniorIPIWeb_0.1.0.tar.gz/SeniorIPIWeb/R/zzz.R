.onLoad <- function(libname, pkgname){
  is_servr <- require("servr")
  if (!is_servr) install.packages("servr")
  SeniorIPIWeb()
}
