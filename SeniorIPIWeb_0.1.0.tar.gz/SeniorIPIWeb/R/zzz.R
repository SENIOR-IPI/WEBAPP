.onLoad <- function(libname, pkgname){
  SeniorIPIWeb()
}
