.onLoad <- function(libname, pkgname){
  message("toto")
  SeniorIPIWeb()
}
